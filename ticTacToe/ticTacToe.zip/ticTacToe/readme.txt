Cargar el modulo principal TicTacToe.hs mediante GHCi.

Ejecutar el programa con el siguiente comando => ticTacToe.